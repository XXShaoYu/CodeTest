//
//  ViewController.m
//  OCCallJS
//
//  Created by sn on 2017/7/25.
//  Copyright © 2017年 sn. All rights reserved.
//

#import "ViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>

@interface ViewController () <UIWebViewDelegate>
@property (nonatomic, strong) UIWebView *webView;
@property (nonatomic, strong) JSContext *context;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIWebView *webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
    NSURL *url = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"test.html" ofType:nil]];
    [webView loadRequest:[NSURLRequest requestWithURL:url]];
    [self.view addSubview:webView];
    self.webView = webView;
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(100, 300, 100, 100);
    btn.backgroundColor = [UIColor redColor];
    [btn addTarget:self action:@selector(jsFromString) forControlEvents:UIControlEventTouchUpInside];
    webView.delegate = self;
    [self.view addSubview:btn];
    
    UIButton *btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn2.frame = CGRectMake(300, 300, 100, 100);
    btn2.backgroundColor = [UIColor redColor];
    [btn2 addTarget:self action:@selector(jsCore) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn2];
}

- (void)jsFromString {
    NSString *jsEvent = @"getUsernameAndPassworld('冀占船', '123456')";
    [self.webView stringByEvaluatingJavaScriptFromString:jsEvent];
}


- (void)webViewDidFinishLoad:(UIWebView *)webView {
    self.context = [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    self.context.exceptionHandler = ^(JSContext *context, JSValue *exceptionValue){
        context.exception = exceptionValue;
    };
}

- (void)jsCore {
    [self.context evaluateScript:@"getUsernameAndPassworld('冀占船', '123456')"];
}

@end
