//
//  main.m
//  OCCallJS
//
//  Created by sn on 2017/7/25.
//  Copyright © 2017年 sn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
